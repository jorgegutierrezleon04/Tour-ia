// grupos.js - simple enhancement
document.addEventListener('DOMContentLoaded', () => {
  // nothing for now; groups are links to planificador.html?group=...
});
